import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./Profile.css";
const Settings = () => {
  return (
    <div>
      <div className="container">
        <p>Settings Details</p>
        <br></br>
      </div>
    </div>
  );
};
export default Settings;
