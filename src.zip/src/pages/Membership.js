import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./Membership.css";
const Membership = () => {
  return (
    <div>
      <h1>Membership</h1>
      <p>accessed by router</p>
      <div className="container">
        <h1>Fuel great thinking.</h1>
      </div>
    </div>
  );
};

export default Membership;
