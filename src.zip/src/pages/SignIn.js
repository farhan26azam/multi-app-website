import React from "react";

const SignIn = () => {
  return (
    <div>
      <h1>Sign in as a User or</h1>
      <h3>Sign in as a guest</h3>
    </div>
  );
};

export default SignIn;
