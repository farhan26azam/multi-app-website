import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./Profile.css";
const Agent = () => {
  return (
    <div>
      <div className="container">
        <p>Agent Details</p>
        <br></br>
      </div>
    </div>
  );
};

export default Agent;
