import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./Profile.css";
const Profile = () => {
  return (
    <div>
      <div className="container profile">
        <p>User Details</p>
        <br></br>
      </div>
    </div>
  );
};

export default Profile;
