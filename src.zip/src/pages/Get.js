import React from "react";

const Get = () => {
  return (
    <div>
      <h1>Let's get started</h1>
    </div>
  );
};

export default Get;
