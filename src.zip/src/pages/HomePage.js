import React from "react";
import { Link } from "react-router-dom";
const HomePage = () => {
  return (
    <React.Fragment>
      <div>HomePage</div>
    </React.Fragment>
  );
};

export default HomePage;
