import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.css";
import "./Message.css";
import Chat from "./Chat";
const Message = () => {
  return (
    <div>
      <Chat />
    </div>
  );
};

export default Message;
