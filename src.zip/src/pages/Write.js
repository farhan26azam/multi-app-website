import React from "react";

const Write = () => {
  return (
    <div>
      <h1>Write with us!</h1>
      <p>Publish, grow, and earn, all in one place.</p>
    </div>
  );
};

export default Write;
